# VVV Transcribe

Internal tool for transcribing Vintage Virtual Vibes owners meetings.
Upload a recording after the meeting; it gets transcribed and stored for reference.

## Stack

- Next.js 14 (App Router) + Tailwind
- Supabase (Postgres for meeting records, Storage for audio files)
- Deepgram for transcription (handles the large WAV files Craig bot produces — no small file-size cap like Whisper's 25MB)

Recordings are still captured with the Craig Discord bot as before — this app just ingests
the resulting audio file, stores it, and transcribes it. Recording live from Discord
directly in this app would mean rebuilding what Craig already does (joining voice channels,
decoding per-user audio streams, etc.), which isn't worth it.

## Setup

1. **Supabase project**
   - Create a new Supabase project (or reuse an existing VVV one).
   - Run `supabase/schema.sql` in the SQL editor to create the `meetings` table.
   - In Storage, create a new **private** bucket named `meeting-audio`.
   - Copy your Project URL, anon key, and service role key into `.env.local` (see `.env.example`).

2. **Deepgram key**
   - Sign up at deepgram.com, grab an API key, add `DEEPGRAM_API_KEY` to `.env.local`.

3. **Shared password**
   - Set `APP_PASSWORD` to whatever you want the 5 of you to use to get in.
   - This gates every route via middleware — no page loads without it.

4. **Install & run**
   ```bash
   npm install
   npm run dev
   ```
   Visit http://localhost:3000

5. **Deploy**
   - Push to a feature branch, then deploy via Vercel same as your other VVV projects.
   - Add the same env vars (including `APP_PASSWORD`) in the Vercel project settings.

## Known limitations / next steps

- **No auto-summary yet.** Could add a follow-up step that sends the transcript to Claude
  or GPT to pull out action items / decisions — easy add if useful.
- **Speaker labels are manual for now.** Deepgram diarizes by voice ("Speaker 0", "Speaker 1"),
  not by identity, so there's a "Rename speakers" control on each transcript to map those
  labels to real names once per meeting. Fine for a 5-person team.
- **Synchronous transcription request.** For a 90-minute file this should complete well
  within the 5-minute function timeout (Deepgram processes much faster than real-time),
  but if you ever hit timeouts, switch to Deepgram's callback-based async API instead.

### Future version: automatic speaker labeling

Craig bot can export a **separate audio track per Discord user**. A future version could:
1. Switch Craig to multi-track recording mode.
2. Transcribe each user's track separately (each one is single-speaker, so no diarization needed).
3. Merge the per-track transcripts back into one chronological conversation using each
   segment's timestamp, labeling each line with the actual Discord username automatically.

This removes the manual renaming step entirely, but the merge-by-timestamp logic is a
real chunk of work — worth doing only if manual renaming becomes a real annoyance.
