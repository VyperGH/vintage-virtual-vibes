import { createClient } from '@supabase/supabase-js';

// Client-side (browser) client — uses the public anon key.
// Safe to expose; RLS policies (see supabase/schema.sql) restrict what it can do.
export const supabaseBrowser = () =>
  createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
  );

// Server-side client — uses the service role key, only ever used inside
// API routes / server actions, NEVER shipped to the client bundle.
export const supabaseServer = () =>
  createClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!,
    { auth: { persistSession: false } }
  );
