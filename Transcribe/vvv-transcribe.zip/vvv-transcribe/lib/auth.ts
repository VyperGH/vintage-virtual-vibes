// Simple shared-password gate for this internal tool — not per-user auth.
// The cookie stores a hash of the password (not the password itself) so it's
// not sitting in plaintext in the browser, but this is still a single shared
// secret for all 5 of you, not real accounts.

export async function hashPassword(password: string): Promise<string> {
  const data = new TextEncoder().encode(password);
  const digest = await crypto.subtle.digest('SHA-256', data);
  return Array.from(new Uint8Array(digest))
    .map((b) => b.toString(16).padStart(2, '0'))
    .join('');
}

export const AUTH_COOKIE_NAME = 'vvv_auth';
