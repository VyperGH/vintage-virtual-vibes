/** @type {import('next').NextConfig} */
const nextConfig = {
  experimental: {
    serverActions: {
      bodySizeLimit: '200mb', // owners meetings can run long; raise if you hit limits
    },
  },
};

module.exports = nextConfig;
