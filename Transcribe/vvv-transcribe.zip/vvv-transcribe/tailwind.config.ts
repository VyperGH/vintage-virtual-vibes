import type { Config } from 'tailwindcss';

const config: Config = {
  content: [
    './app/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {
      colors: {
        vvv: {
          bg: '#0d0d14',
          panel: '#16161f',
          accent: '#ff2fb0',   // retrowave pink, matches NEON DRIVE pack vibe
          accent2: '#2fe0ff',  // cyan accent
        },
      },
    },
  },
  plugins: [],
};

export default config;
