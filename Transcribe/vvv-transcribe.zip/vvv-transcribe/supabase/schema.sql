-- Run this in the Supabase SQL editor for your project.

create table if not exists meetings (
  id uuid primary key default gen_random_uuid(),
  title text not null default 'Untitled Meeting',
  meeting_date date not null default current_date,
  audio_path text,              -- path in the 'meeting-audio' storage bucket
  status text not null default 'uploaded', -- uploaded | transcribing | complete | error
  transcript text,
  speaker_map jsonb not null default '{}'::jsonb, -- e.g. {"Speaker 0": "Wyld", "Speaker 1": "Distrought"}
  summary text,                 -- optional AI-generated summary / action items
  duration_seconds int,
  error_message text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- Storage bucket for the raw audio/video files.
-- Create this via the Supabase dashboard (Storage > New bucket) named "meeting-audio",
-- or uncomment and run below if you have the storage extension permissions.
-- insert into storage.buckets (id, name, public) values ('meeting-audio', 'meeting-audio', false);

alter table meetings enable row level security;

-- If you already ran this schema before speaker_map existed, run this once:
-- alter table meetings add column if not exists speaker_map jsonb not null default '{}'::jsonb;

-- The browser uploads audio files directly to Storage using the public anon key,
-- so Storage's own RLS (separate from the "meetings" table policy above) needs to
-- explicitly allow that, or you'll get "new row violates row-level security policy"
-- on upload.
create policy "allow uploads to meeting-audio"
on storage.objects for insert
to anon
with check (bucket_id = 'meeting-audio');

-- Since this is an internal 5-person tool with no per-user auth yet,
-- start locked down to the service role only (server-side API routes).
-- Tighten/loosen once you decide whether VVV members get individual logins.
create policy "service role full access"
  on meetings
  for all
  using (auth.role() = 'service_role');
