'use client';

import { useMemo, useState } from 'react';

type Props = {
  meetingId: string;
  transcript: string;
  speakerMap: Record<string, string>;
  onSpeakerMapSaved: (newMap: Record<string, string>) => void;
};

const SPEAKER_REGEX = /Speaker \d+(?=:)/g;

export default function TranscriptView({
  meetingId,
  transcript,
  speakerMap,
  onSpeakerMapSaved,
}: Props) {
  const rawSpeakers = useMemo(
    () => Array.from(new Set(transcript.match(SPEAKER_REGEX) || [])),
    [transcript]
  );

  const [editing, setEditing] = useState(false);
  const [draftMap, setDraftMap] = useState<Record<string, string>>(speakerMap);
  const [saving, setSaving] = useState(false);

  const displayedTranscript = useMemo(() => {
    if (Object.keys(speakerMap).length === 0) return transcript;
    let out = transcript;
    for (const [raw, name] of Object.entries(speakerMap)) {
      if (name) out = out.split(`${raw}:`).join(`${name}:`);
    }
    return out;
  }, [transcript, speakerMap]);

  async function save() {
    setSaving(true);
    const res = await fetch(`/api/meetings/${meetingId}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ speakerMap: draftMap }),
    });
    if (res.ok) {
      onSpeakerMapSaved(draftMap);
      setEditing(false);
    }
    setSaving(false);
  }

  if (rawSpeakers.length === 0) {
    // No diarized speaker labels in this transcript — just show it as-is.
    return (
      <pre className="mt-3 whitespace-pre-wrap text-sm bg-black/30 p-3 rounded max-h-96 overflow-y-auto">
        {transcript}
      </pre>
    );
  }

  return (
    <div className="mt-3 space-y-2">
      <div className="flex justify-between items-center">
        <span className="text-xs text-white/50">
          {rawSpeakers.length} speaker{rawSpeakers.length > 1 ? 's' : ''} detected
        </span>
        <button
          onClick={() => setEditing((e) => !e)}
          className="text-vvv-accent text-xs underline"
        >
          {editing ? 'Cancel' : 'Rename speakers'}
        </button>
      </div>

      {editing && (
        <div className="bg-black/30 p-3 rounded space-y-2">
          {rawSpeakers.map((raw) => (
            <div key={raw} className="flex items-center gap-2">
              <span className="text-xs text-white/50 w-24 shrink-0">{raw}</span>
              <input
                type="text"
                placeholder="Name"
                value={draftMap[raw] || ''}
                onChange={(e) => setDraftMap((m) => ({ ...m, [raw]: e.target.value }))}
                className="flex-1 rounded bg-black/40 border border-white/10 px-2 py-1 text-sm"
              />
            </div>
          ))}
          <button
            onClick={save}
            disabled={saving}
            className="bg-vvv-accent hover:opacity-90 disabled:opacity-40 text-white text-sm font-medium px-3 py-1.5 rounded"
          >
            {saving ? 'Saving…' : 'Save names'}
          </button>
        </div>
      )}

      <pre className="whitespace-pre-wrap text-sm bg-black/30 p-3 rounded max-h-96 overflow-y-auto">
        {displayedTranscript}
      </pre>
    </div>
  );
}
