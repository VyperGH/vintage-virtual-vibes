'use client';

import { useEffect, useState } from 'react';
import TranscriptView from './TranscriptView';

type Meeting = {
  id: string;
  title: string;
  meeting_date: string;
  status: string;
  transcript: string | null;
  speaker_map: Record<string, string>;
  error_message: string | null;
};

export default function MeetingList({ refreshKey }: { refreshKey: number }) {
  const [meetings, setMeetings] = useState<Meeting[]>([]);
  const [openId, setOpenId] = useState<string | null>(null);

  async function load() {
    const res = await fetch('/api/meetings');
    const { meetings } = await res.json();
    setMeetings(meetings || []);
  }

  useEffect(() => {
    load();
  }, [refreshKey]);

  function updateSpeakerMap(meetingId: string, newMap: Record<string, string>) {
    setMeetings((prev) =>
      prev.map((m) => (m.id === meetingId ? { ...m, speaker_map: newMap } : m))
    );
  }

  return (
    <div className="space-y-3">
      <h2 className="text-lg font-semibold text-vvv-accent2">Meetings</h2>
      {meetings.length === 0 && <p className="text-white/50 text-sm">No meetings yet.</p>}
      {meetings.map((m) => (
        <div key={m.id} className="bg-vvv-panel border border-white/10 rounded-lg p-4">
          <div className="flex justify-between items-center">
            <div>
              <p className="font-medium">{m.title}</p>
              <p className="text-xs text-white/50">{m.meeting_date} · {m.status}</p>
            </div>
            {m.status === 'complete' && (
              <button
                onClick={() => setOpenId(openId === m.id ? null : m.id)}
                className="text-vvv-accent text-sm underline"
              >
                {openId === m.id ? 'Hide transcript' : 'View transcript'}
              </button>
            )}
          </div>
          {m.status === 'error' && (
            <p className="text-red-400 text-xs mt-2">{m.error_message}</p>
          )}
          {openId === m.id && m.transcript && (
            <TranscriptView
              meetingId={m.id}
              transcript={m.transcript}
              speakerMap={m.speaker_map || {}}
              onSpeakerMapSaved={(newMap) => updateSpeakerMap(m.id, newMap)}
            />
          )}
        </div>
      ))}
    </div>
  );
}
