'use client';

import { useState } from 'react';
import { supabaseBrowser } from '@/lib/supabase';

export default function UploadForm({ onUploaded }: { onUploaded: () => void }) {
  const [title, setTitle] = useState('');
  const [file, setFile] = useState<File | null>(null);
  const [status, setStatus] = useState<string>('');
  const [busy, setBusy] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!file) return;
    setBusy(true);
    setStatus('Uploading audio…');

    try {
      const supabase = supabaseBrowser();
      const path = `${Date.now()}-${file.name}`;

      const { error: uploadError } = await supabase.storage
        .from('meeting-audio')
        .upload(path, file);

      if (uploadError) throw uploadError;

      setStatus('Creating meeting record…');
      const createRes = await fetch('/api/meetings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: title || file.name,
          meetingDate: new Date().toISOString().slice(0, 10),
          audioPath: path,
        }),
      });
      const { meeting, error: createError } = await createRes.json();
      if (createError) throw new Error(createError);

      setStatus('Transcribing (this can take a few minutes for long meetings)…');
      const transcribeRes = await fetch('/api/transcribe', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ meetingId: meeting.id }),
      });
      const transcribeData = await transcribeRes.json();
      if (transcribeData.error) throw new Error(transcribeData.error);

      setStatus('Done!');
      setTitle('');
      setFile(null);
      onUploaded();
    } catch (err: any) {
      setStatus(`Error: ${err.message || err}`);
    } finally {
      setBusy(false);
    }
  }

  return (
    <form onSubmit={handleSubmit} className="bg-vvv-panel p-6 rounded-lg space-y-4 border border-white/10">
      <h2 className="text-lg font-semibold text-vvv-accent2">Upload a meeting recording</h2>

      <input
        type="text"
        placeholder="Meeting title (e.g. July Owners Meeting)"
        value={title}
        onChange={(e) => setTitle(e.target.value)}
        className="w-full rounded bg-black/30 border border-white/10 px-3 py-2 text-sm"
      />

      <input
        type="file"
        accept="audio/*,video/*"
        onChange={(e) => setFile(e.target.files?.[0] || null)}
        className="w-full text-sm"
      />

      <button
        type="submit"
        disabled={busy || !file}
        className="bg-vvv-accent hover:opacity-90 disabled:opacity-40 text-white font-medium px-4 py-2 rounded"
      >
        {busy ? 'Working…' : 'Upload & Transcribe'}
      </button>

      {status && <p className="text-sm text-white/70">{status}</p>}
    </form>
  );
}
