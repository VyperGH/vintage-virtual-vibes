'use client';

import { useState } from 'react';
import UploadForm from './components/UploadForm';
import MeetingList from './components/MeetingList';

export default function Home() {
  const [refreshKey, setRefreshKey] = useState(0);

  return (
    <main className="max-w-2xl mx-auto px-4 py-12 space-y-8">
      <div>
        <h1 className="text-2xl font-bold text-white">Vintage Virtual Vibes</h1>
        <p className="text-white/50 text-sm">Owners meeting transcripts</p>
      </div>

      <UploadForm onUploaded={() => setRefreshKey((k) => k + 1)} />
      <MeetingList refreshKey={refreshKey} />
    </main>
  );
}
