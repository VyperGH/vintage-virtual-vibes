import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'Vintage Virtual Vibes — Meeting Transcripts',
  description: 'Internal transcription tool for Vintage Virtual Vibes owners meetings',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body className="min-h-screen bg-vvv-bg">{children}</body>
    </html>
  );
}
