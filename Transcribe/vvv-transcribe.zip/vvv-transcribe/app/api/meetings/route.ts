import { NextRequest, NextResponse } from 'next/server';
import { supabaseServer } from '@/lib/supabase';

export async function GET() {
  const supabase = supabaseServer();
  const { data, error } = await supabase
    .from('meetings')
    .select('*')
    .order('created_at', { ascending: false });

  if (error) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
  return NextResponse.json({ meetings: data });
}

export async function POST(req: NextRequest) {
  const supabase = supabaseServer();
  const { title, meetingDate, audioPath } = await req.json();

  const { data, error } = await supabase
    .from('meetings')
    .insert({
      title: title || 'Untitled Meeting',
      meeting_date: meetingDate || new Date().toISOString().slice(0, 10),
      audio_path: audioPath,
      status: 'uploaded',
    })
    .select()
    .single();

  if (error) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
  return NextResponse.json({ meeting: data });
}
