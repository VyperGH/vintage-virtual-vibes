import { NextRequest, NextResponse } from 'next/server';
import { supabaseServer } from '@/lib/supabase';

export async function PATCH(req: NextRequest, { params }: { params: { id: string } }) {
  const { speakerMap } = await req.json();
  const supabase = supabaseServer();

  const { data, error } = await supabase
    .from('meetings')
    .update({ speaker_map: speakerMap })
    .eq('id', params.id)
    .select()
    .single();

  if (error) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
  return NextResponse.json({ meeting: data });
}
