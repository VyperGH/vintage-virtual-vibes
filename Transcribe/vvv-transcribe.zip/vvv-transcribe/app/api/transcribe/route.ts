import { NextRequest, NextResponse } from 'next/server';
import { supabaseServer } from '@/lib/supabase';

// Deepgram handles long/large audio files (Craig bot WAV exports of 700MB+ are fine)
// with no small size ceiling like Whisper's 25MB cap.
export const maxDuration = 300; // Vercel Pro+ needed to go above 60s; Deepgram is usually much faster than real-time

const SIGNED_URL_EXPIRY_SECONDS = 60 * 60; // 1 hour — plenty for Deepgram to fetch the file

export async function POST(req: NextRequest) {
  try {
    const { meetingId } = await req.json();
    if (!meetingId) {
      return NextResponse.json({ error: 'meetingId is required' }, { status: 400 });
    }

    const supabase = supabaseServer();

    const { data: meeting, error: fetchError } = await supabase
      .from('meetings')
      .select('*')
      .eq('id', meetingId)
      .single();

    if (fetchError || !meeting) {
      return NextResponse.json({ error: 'Meeting not found' }, { status: 404 });
    }

    await supabase
      .from('meetings')
      .update({ status: 'transcribing' })
      .eq('id', meetingId);

    // Instead of downloading the (potentially 700MB+) file into this function's
    // memory, hand Deepgram a signed URL and let it fetch the file directly.
    const { data: signedUrlData, error: signedUrlError } = await supabase.storage
      .from('meeting-audio')
      .createSignedUrl(meeting.audio_path, SIGNED_URL_EXPIRY_SECONDS);

    if (signedUrlError || !signedUrlData) {
      await supabase
        .from('meetings')
        .update({ status: 'error', error_message: 'Could not create signed URL for audio' })
        .eq('id', meetingId);
      return NextResponse.json({ error: 'Could not create signed URL' }, { status: 500 });
    }

    const deepgramRes = await fetch(
      'https://api.deepgram.com/v1/listen?smart_format=true&diarize=true&punctuate=true',
      {
        method: 'POST',
        headers: {
          Authorization: `Token ${process.env.DEEPGRAM_API_KEY}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ url: signedUrlData.signedUrl }),
      }
    );

    if (!deepgramRes.ok) {
      const errText = await deepgramRes.text();
      await supabase
        .from('meetings')
        .update({ status: 'error', error_message: `Deepgram error: ${errText}` })
        .eq('id', meetingId);
      return NextResponse.json({ error: `Deepgram error: ${errText}` }, { status: 500 });
    }

    const deepgramData = await deepgramRes.json();

    // Deepgram's diarized output comes as "paragraphs" with speaker labels when
    // available; fall back to the plain transcript if paragraphs aren't present.
    const channel = deepgramData?.results?.channels?.[0];
    const paragraphs = channel?.alternatives?.[0]?.paragraphs?.paragraphs;
    let transcript: string;

    if (paragraphs && paragraphs.length > 0) {
      transcript = paragraphs
        .map((p: any) => {
          const text = p.sentences.map((s: any) => s.text).join(' ');
          return `Speaker ${p.speaker}: ${text}`;
        })
        .join('\n\n');
    } else {
      transcript = channel?.alternatives?.[0]?.transcript || '';
    }

    await supabase
      .from('meetings')
      .update({
        status: 'complete',
        transcript,
        updated_at: new Date().toISOString(),
      })
      .eq('id', meetingId);

    return NextResponse.json({ success: true });
  } catch (err: any) {
    console.error('Transcription error:', err);
    return NextResponse.json(
      { error: err.message || 'Unknown transcription error' },
      { status: 500 }
    );
  }
}
