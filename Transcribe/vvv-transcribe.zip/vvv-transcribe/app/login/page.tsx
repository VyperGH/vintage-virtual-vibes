'use client';

import { Suspense, useState } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';

function LoginForm() {
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const router = useRouter();
  const searchParams = useSearchParams();

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError('');

    const res = await fetch('/api/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ password }),
    });

    if (res.ok) {
      const dest = searchParams.get('from') || '/';
      router.push(dest);
      router.refresh();
    } else {
      const { error } = await res.json();
      setError(error || 'Something went wrong');
    }
    setBusy(false);
  }

  return (
    <form
      onSubmit={handleSubmit}
      className="bg-vvv-panel p-6 rounded-lg space-y-4 border border-white/10"
    >
      <h1 className="text-lg font-semibold text-white">Vintage Virtual Vibes</h1>
      <p className="text-sm text-white/50">Enter the shared password to continue.</p>

      <input
        type="password"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
        className="w-full rounded bg-black/30 border border-white/10 px-3 py-2 text-sm"
        autoFocus
      />

      <button
        type="submit"
        disabled={busy || !password}
        className="w-full bg-vvv-accent hover:opacity-90 disabled:opacity-40 text-white font-medium px-4 py-2 rounded"
      >
        {busy ? 'Checking…' : 'Enter'}
      </button>

      {error && <p className="text-red-400 text-sm">{error}</p>}
    </form>
  );
}

export default function LoginPage() {
  return (
    <main className="max-w-sm mx-auto px-4 py-24">
      <Suspense fallback={null}>
        <LoginForm />
      </Suspense>
    </main>
  );
}
