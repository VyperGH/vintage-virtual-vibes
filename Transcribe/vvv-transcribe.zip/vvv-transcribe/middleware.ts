import { NextRequest, NextResponse } from 'next/server';
import { hashPassword, AUTH_COOKIE_NAME } from '@/lib/auth';

export async function middleware(req: NextRequest) {
  const { pathname } = req.nextUrl;

  // Always let the login page and its API route through, plus Next's internals.
  if (
    pathname.startsWith('/login') ||
    pathname.startsWith('/api/login') ||
    pathname.startsWith('/_next') ||
    pathname.startsWith('/favicon')
  ) {
    return NextResponse.next();
  }

  const expected = await hashPassword(process.env.APP_PASSWORD || '');
  const cookie = req.cookies.get(AUTH_COOKIE_NAME)?.value;

  if (!process.env.APP_PASSWORD || cookie !== expected) {
    const loginUrl = new URL('/login', req.url);
    loginUrl.searchParams.set('from', pathname);
    return NextResponse.redirect(loginUrl);
  }

  return NextResponse.next();
}

export const config = {
  matcher: ['/((?!_next/static|_next/image).*)'],
};
